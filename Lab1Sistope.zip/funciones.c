// Aquí escribes el cuerpo de las funciones (la lógica de lectura binaria, la erosión, etc.).
#include "funciones.h"

// --- PASO 2: GESTIÓN DE ARCHIVOS BINARIOS ---

// Entradas: Ruta del archivo .bin
// Salidas: Estructura Imagen con datos cargados
// Descripción: Lee la cabecera (ancho/alto) y carga los píxeles en memoria dinámica.
Imagen leerImagen(char *nombreArchivo) {
    FILE *archivo = fopen(nombreArchivo, "rb");
    Imagen img;
    
    if (archivo == NULL) {
         perror("Error al abrir archivo de entrada");
         exit(EXIT_FAILURE);
     }
    
    // Leer Ancho y Alto (4 bytes cada uno)
    fread(&img.ancho, sizeof(int), 1, archivo);
    fread(&img.alto, sizeof(int), 1, archivo);
    
    // Reserva de memoria para píxeles (1 byte por píxel)
    img.pixeles = (unsigned char *)malloc(img.ancho * img.alto);
    if (img.pixeles == NULL) {
        fclose(archivo);
        exit(EXIT_FAILURE);
    }
         
    // Carga de píxeles
    fread(img.pixeles, sizeof(unsigned char), img.ancho * img.alto, archivo);
    fclose(archivo);
    
    return img;
}

// Entradas: Ruta de salida y estructura Imagen
// Salidas: Ninguna
// Descripción: Guarda la imagen en formato binario con cabecera (Ancho, Alto, Data).
void guardarImagenBin(char *nombreArchivo, Imagen img) {
    FILE *archivo = fopen(nombreArchivo, "wb");
    if (archivo == NULL) return;
         
    fwrite(&img.ancho, sizeof(int), 1, archivo);
    fwrite(&img.alto, sizeof(int), 1, archivo); 
    fwrite(img.pixeles, sizeof(unsigned char), img.ancho * img.alto, archivo);
         
    fclose(archivo);
}

// --- PASO 3: PREPROCESAMIENTO (MORFOLOGÍA) ---

// Entradas: Imagen original
// Salidas: Imagen erosionada
// Descripción: Reduce objetos usando elemento estructurante de cruz 3x3.
Imagen aplicarErosion(Imagen original) {
    Imagen resultado;
    resultado.ancho = original.ancho;
    resultado.alto = original.alto;
    
    // calloc inicializa en 0 (negro), lo cual es ideal para evitar basura en la memoria
    resultado.pixeles = (unsigned char *)calloc(resultado.ancho * resultado.alto, 1);
    
    // Se recorre desde 1 hasta ancho/alto - 1 para evitar segment faults en los bordes
    for (int y = 1; y < original.alto - 1; y++) {
        for (int x = 1; x < original.ancho - 1; x++) {
            int idx = y * original.ancho + x;
            
            // Verifica si el centro y sus 4 vecinos directos (cruz) son blancos
            // idx - ancho = Arriba | idx + ancho = Abajo | idx - 1 = Izq | idx + 1 = Der
            if (original.pixeles[idx] == 1 && 
                original.pixeles[idx - original.ancho] == 1 && 
                original.pixeles[idx + original.ancho] == 1 && 
                original.pixeles[idx - 1] == 1 &&             
                original.pixeles[idx + 1] == 1) {             
                
                resultado.pixeles[idx] = 1;
            }
        }
    }
    return resultado;
}

// Entradas: Imagen erosionada
// Salidas: Imagen dilatada
// Descripción: Restaura el tamaño de los círculos expandiendo los píxeles blancos.
Imagen aplicarDilatacion(Imagen erosionada) {
    Imagen resultado;
    resultado.ancho = erosionada.ancho;
    resultado.alto = erosionada.alto;
    resultado.pixeles = (unsigned char *)calloc(resultado.ancho * resultado.alto, 1);
    
    for (int y = 1; y < erosionada.alto - 1; y++) {
        for (int x = 1; x < erosionada.ancho - 1; x++) {
            int idx = y * erosionada.ancho + x;
            
            // Si el centro o cualquier vecino directo en cruz es blanco, el resultado es blanco
            if (erosionada.pixeles[idx] == 1 || 
                erosionada.pixeles[idx - erosionada.ancho] == 1 || 
                erosionada.pixeles[idx + erosionada.ancho] == 1 || 
                erosionada.pixeles[idx - 1] == 1 || 
                erosionada.pixeles[idx + 1] == 1) {
                
                resultado.pixeles[idx] = 1;
            }
        }
    }
    return resultado;
}

// Entradas: Imagen original y procesada
// Salidas: Imagen con el ruido eliminado
// Descripción: Resta la imagen limpia de la original para identificar el ruido.
Imagen obtenerRuido(Imagen original, Imagen procesada) {
    Imagen ruido;
    ruido.ancho = original.ancho;
    ruido.alto = original.alto;
    ruido.pixeles = (unsigned char *)malloc(ruido.ancho * ruido.alto);
    
    for (int i = 0; i < original.ancho * original.alto; i++) {
        ruido.pixeles[i] = (original.pixeles[i] == 1 && procesada.pixeles[i] == 0) ? 1 : 0;
    }
    return ruido;
}

// --- PASO 4: TRANSFORMADA DE HOUGH ---

// Entradas: Imagen limpia, radio r, umbral t y nombre del reporte
// Salidas: Ninguna (genera reporte.csv)
// Descripción: Vota en un acumulador para detectar centros de círculos.
void detectarCirculos(Imagen img, int r, int t, char *archivoSalida) {
    // Inicializar plano acumulador de votos en 0
    int *acumulador = (int *)calloc(img.ancho * img.alto, sizeof(int)); 
    
    const double PI = 3.14159265;
    
    // Proceso de votación
    for (int y = 0; y < img.alto; y++) {
        for (int x = 0; x < img.ancho; x++) {
            
            // Solo votan los píxeles que pertenecen a un borde (blancos)
            if (img.pixeles[y * img.ancho + x] == 1) {
                
                // Ecuación paramétrica del círculo. 
                // El incremento theta de 1.0 / r asegura que se vote exactamente un píxel a la vez en la circunferencia
                for (double theta = 0; theta < 2 * PI; theta += 1.0 / r) { 
                     int a = (int)(x - r * cos(theta)); 
                     int b = (int)(y - r * sin(theta)); 
                     
                     // Verificar límites de la imagen para no acceder a memoria inválida
                     if (a >= 0 && a < img.ancho && b >= 0 && b < img.alto) {
                         acumulador[b * img.ancho + a]++; 
                     }
                }
            }
        }
    }
    
    // Generar reporte CSV
    FILE *f = fopen(archivoSalida, "w");
    if (f == NULL) { 
        free(acumulador); 
        return; 
    }
         
    fprintf(f, "X,Y\n"); // Cabecera del archivo
    
    for (int i = 0; i < img.ancho * img.alto; i++) {
        // Validar centros según el umbral t
        if (acumulador[i] >= t) { 
             fprintf(f, "%d,%d\n", i % img.ancho, i / img.ancho);
        }
    }
         
    fclose(f);
    free(acumulador); 
}