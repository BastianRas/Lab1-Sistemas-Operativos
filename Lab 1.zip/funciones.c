//Aquí escribes el cuerpo de las funciones (la lógica de lectura binaria, la erosión, etc.).
#include "funciones.h"

// --- PASO 2: GESTIÓN DE ARCHIVOS BINARIOS ---

// Entradas: Ruta del archivo .bin
// Salidas: Estructura Imagen con datos cargados
// Descripción: Lee la cabecera (ancho/alto) y carga los píxeles en memoria dinámica[cite: 149, 150, 194].
Imagen leerImagen(char *nombreArchivo) {
    FILE *archivo = fopen(nombreArchivo, "rb");
    Imagen img;
    if (archivo == NULL) { 
        perror("Error al abrir archivo de entrada"); 
        exit(EXIT_FAILURE); 
    }

    // Leer Ancho y Alto (4 bytes cada uno) [cite: 84, 85, 196]
    fread(&img.ancho, sizeof(int), 1, archivo);
    fread(&img.alto, sizeof(int), 1, archivo);

    // Reserva de memoria para píxeles (1 byte por píxel) [cite: 151, 197]
    img.pixeles = (unsigned char *)malloc(img.ancho * img.alto);
    if (img.pixeles == NULL) {
        fclose(archivo);
        exit(EXIT_FAILURE);
    }
    
    // Carga de píxeles [cite: 198]
    fread(img.pixeles, sizeof(unsigned char), img.ancho * img.alto, archivo);

    fclose(archivo);
    return img;
}

// Entradas: Ruta de salida y estructura Imagen
// Salidas: Ninguna
// Descripción: Guarda la imagen en formato binario con cabecera (Ancho, Alto, Data)[cite: 152, 201].
void guardarImagenBin(char *nombreArchivo, Imagen img) {
    FILE *archivo = fopen(nombreArchivo, "wb");
    if (archivo == NULL) return;
    
    fwrite(&img.ancho, sizeof(int), 1, archivo); // [cite: 202]
    fwrite(&img.alto, sizeof(int), 1, archivo);  // [cite: 202]
    fwrite(img.pixeles, sizeof(unsigned char), img.ancho * img.alto, archivo); // [cite: 203]
    
    fclose(archivo);
}

// --- PASO 3: PREPROCESAMIENTO (MORFOLOGÍA) ---

// Entradas: Imagen original
// Salidas: Imagen erosionada
// Descripción: Reduce objetos usando elemento estructurante de cruz 3x3[cite: 41, 61, 154].
Imagen aplicarErosion(Imagen original) {
    Imagen resultado;
    resultado.ancho = original.ancho;
    resultado.alto = original.alto;
    resultado.pixeles = (unsigned char *)calloc(resultado.ancho * resultado.alto, 1); // [cite: 288]

    for (int y = 1; y < original.alto - 1; y++) {
        for (int x = 1; x < original.ancho - 1; x++) {
            int idx = y * original.ancho + x;
            // Verifica si el centro y sus 4 vecinos son blancos [cite: 257, 279]
            if (original.pixeles[idx] == 1 && 
                original.pixeles[idx - original.ancho] == 1 && // Arriba
                original.pixeles[idx + original.ancho] == 1 && // Abajo
                original.pixeles[idx - 1] == 1 &&              // Izquierda
                original.pixeles[idx + 1] == 1) {              // Derecha
                resultado.pixeles[idx] = 1;
            }
        }
    }
    return resultado;
}

// Entradas: Imagen erosionada
// Salidas: Imagen dilatada
// Descripción: Restaura el tamaño de los círculos expandiendo los píxeles blancos[cite: 62, 156, 261].
Imagen aplicarDilatacion(Imagen erosionada) {
    Imagen resultado;
    resultado.ancho = erosionada.ancho;
    resultado.alto = erosionada.alto;
    resultado.pixeles = (unsigned char *)calloc(resultado.ancho * resultado.alto, 1);

    for (int y = 1; y < erosionada.alto - 1; y++) {
        for (int x = 1; x < erosionada.ancho - 1; x++) {
            int idx = y * erosionada.ancho + x;
            // Si el centro o cualquier vecino es blanco, el resultado es blanco [cite: 280]
            if (erosionada.pixeles[idx] == 1 || 
                erosionada.pixeles[idx - erosionada.ancho] == 1 || 
                erosionada.pixeles[idx + erosionada.ancho] == 1 || 
                erosionada.pixeles[idx - 1] == 1 || 
                erosionada.pixeles[idx + 1] == 1) {
                resultado.pixeles[idx] = 1;
            }
        }
    }
    return resultado;
}

// Entradas: Imagen original y procesada
// Salidas: Imagen con el ruido eliminado
// Descripción: Resta la imagen limpia de la original para identificar el ruido[cite: 157, 263, 281].
Imagen obtenerRuido(Imagen original, Imagen procesada) {
    Imagen ruido;
    ruido.ancho = original.ancho;
    ruido.alto = original.alto;
    ruido.pixeles = (unsigned char *)malloc(ruido.ancho * ruido.alto);
    for (int i = 0; i < original.ancho * original.alto; i++) {
        ruido.pixeles[i] = (original.pixeles[i] == 1 && procesada.pixeles[i] == 0) ? 1 : 0;
    }
    return ruido;
}

// --- PASO 4: TRANSFORMADA DE HOUGH ---

// Entradas: Imagen limpia, radio r, umbral t y nombre del reporte
// Salidas: Ninguna (genera reporte.csv)
// Descripción: Vota en un acumulador para detectar centros de círculos[cite: 29, 63, 305].
void detectarCirculos(Imagen img, int r, int t, char *archivoSalida) {
    // Inicializar plano acumulador de votos [cite: 19, 159, 170]
    int *acumulador = (int *)calloc(img.ancho * img.alto, sizeof(int)); 
    const double PI = 3.14159265;

    // Proceso de votación [cite: 160]
    for (int y = 0; y < img.alto; y++) {
        for (int x = 0; x < img.ancho; x++) {
            // Solo votan los píxeles que pertenecen a un borde (blancos)
            if (img.pixeles[y * img.ancho + x] == 1) {
                // Ecuación paramétrica del círculo [cite: 64, 65]
                for (double theta = 0; theta < 2 * PI; theta += 0.1) { 
                    int a = (int)(x - r * cos(theta)); 
                    int b = (int)(y - r * sin(theta)); 
                    // Verificar límites de la imagen [cite: 161]
                    if (a >= 0 && a < img.ancho && b >= 0 && b < img.alto) {
                        acumulador[b * img.ancho + a]++; 
                    }
                }
            }
        }
    }

    // Generar reporte CSV [cite: 164]
    FILE *f = fopen(archivoSalida, "w");
    if (f == NULL) { free(acumulador); return; }
    
    fprintf(f, "X, Y\n"); // Cabecera del archivo [cite: 98]
    for (int i = 0; i < img.ancho * img.alto; i++) {
        // Validar centros según el umbral t [cite: 39, 53, 163]
        if (acumulador[i] >= t) { 
            fprintf(f, "%d,%d\n", i % img.ancho, i / img.ancho);
        }
    }
    
    fclose(f);
    free(acumulador); // Liberar memoria del acumulador
}