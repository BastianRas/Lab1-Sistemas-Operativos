#include <unistd.h>
#include <getopt.h>
#include "funciones.h"

int main(int argc, char *argv[]) {
    char *input = NULL, *output = NULL;
    int r = 0, t = 0, d = 0, opt;

    // Procesamiento de flags: -i (input), -r (radio), -t (umbral), -o (output), -d (debug)
    while ((opt = getopt(argc, argv, "i:r:t:o:d")) != -1) {
        switch (opt) {
            case 'i': input = optarg; break;
            case 'r': r = atoi(optarg); break;
            case 't': t = atoi(optarg); break;
            case 'o': output = optarg; break;
            case 'd': d = 1; break;
        }
    }

    if (!input || !output || r <= 0 || t <= 0) {
        fprintf(stderr, "Uso: ./lab1 -i entrada.bin -r radio -t umbral -o reporte.csv [-d]\n");
        return 1;
    }

    Imagen original = leerImagen(input);
    Imagen erosionada = aplicarErosion(original);
    Imagen limpia = aplicarDilatacion(erosionada);

    if (d) {
        guardarImagenBin("erosionada.bin", erosionada);
        guardarImagenBin("preprocesada.bin", limpia);
        Imagen ruido = obtenerRuido(original, limpia);
        guardarImagenBin("ruido.bin", ruido);
        free(ruido.pixeles);
    }

    detectarCirculos(limpia, r, t, output);

    free(original.pixeles); 
    free(erosionada.pixeles); 
    free(limpia.pixeles);
    
    return 0;
}