#ifndef FUNCIONES_H
#define FUNCIONES_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Estructura para representar la imagen binaria
typedef struct {
    int ancho;          // 4 bytes
    int alto;           // 4 bytes
    unsigned char *pixeles; // Bloque de memoria (1 byte por pixel)
} Imagen;

//funciones.c
Imagen leerImagen(char *nombreArchivo);
void guardarImagenBin(char *nombreArchivo, Imagen img);
Imagen aplicarErosion(Imagen original);
Imagen aplicarDilatacion(Imagen erosionada);
Imagen obtenerRuido(Imagen original, Imagen procesada);
void detectarCirculos(Imagen img, int r, int t, char *archivoSalida);

#endif