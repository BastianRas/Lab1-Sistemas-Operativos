Ejecución:
Paso 1: Preparación del entorno
Descargamos y descomprimimos el archivo .zip. Debemos verificar que la carpeta contenga los siguientes archivos: 
funciones.c, funciones.h, GenerarDatos.py, Makefile, lab1.c, VerificacionVisual.py y Visualizer.py.

Paso 2: Acceso a la carpeta desde la terminal
Copiamos la dirección de la carpeta que acabamos de descomprimir. Luego, abrimos la terminal de Ubuntu y usamos el comando: 
( cd [direccion de la carpeta]) 
para acceder a la cerpeta desde el terminal.

Paso 3: Compilación del código
Una vez dentro de la carpeta en la terminal, para compilar el código utilizamos el comando: 
( make )
Esto le indica a Ubuntu que lea el archivo Makefile y construya el programa en C como resultado, 
se generarán los archivos: lab1.o, funciones.o y el archivo ejecutable final llamado lab1.

Paso 4: Generación de datos de prueba
Creamos una imagen binaria ruidosa para que el programa trabaje sobre ella con el siguiente comando:
( python3 GenerarDatos.py -o entrada.bin -r 50 -p 0.01 )
donde:
-o entrada.bin: es el nombre del archivo de imagen que se va a crear.
-r 50: Establece el radio de los círculos generados (en este caso de 50 pixeles).
-p 0.01: Agrega el ruido de sal a la imagen (en este caso 1% de ruido).

Paso 5: Ejecución del procesamiento en C
Procesamos la imagen aplicando la limpieza mediante morfología y la detección mediante la Transformada de Hough. creando automáticamente los archivos de las etapas intermedias que son la erosión y la dilatación, junto al reporte CSV cual guarda las coordenadas (X, Y) de los centro de círculos detectados. Ejecutamos el siguiente comando:
( ./lab1 -i entrada.bin -r 50 -t 100 -o reporte.csv -d )
donde:
-i entrada.bin: Le indica al programa cuál es la imagen ruidosa original que debe procesar.  
-r 50: Es el radio de los círculos que el algoritmo va a buscar (Usamos 50 para que coincida con los datos que generamos).  
-t 100: Es el umbral de confianza. Le indica al programa el número mínimo de votos que necesita un píxel en el acumulador para ser considerado y validado como un centro real.  
-o reporte.csv: Define el nombre del archivo de salida (con las coordenadas de los centros de los círculos).  
-d: Activa la depuración. separando las etapas intermedias/subproductos del proceso (erosionada.bin, preprocesada.bin y ruido.bin esta ultima es el resultado de entrada-preprocesada) en nuestra carpeta.  

Paso 6: Generación de imágenes legibles 
Ya teniendo todos los archivos binarios y el archivo CSV generados, vamos a transformarlos en imágenes PNG. 

FOTO 1:
Para obtener la primera foto, que corresponde a la imagen ruidosa original (entrada), usamos el siguiente comando:
( python3 Visualizer.py entrada.bin 1_entrada.png )
donde:
entrada.bin: Es el archivo binario original que queremos convertir a imagen visual.  
1_entrada.png: Es el nombre del archivo de imagen final (PNG) que se va a crear y guardar en nuestra carpeta.

FOTO2:
Para obtener la segunda foto, que corresponde a la imagen erosionada la cual logramos que los puntos pequeños (ruido de sal) desaparezcan por completo de la imagen, usamos el siguiente comando:
( python3 Visualizer.py erosionada.bin 2_erosion.png )
donde:
erosionada.bin: Es el archivo binario original que queremos convertir a imagen visual.  
2_erosion.png: Es el nombre del archivo de imagen final (PNG) que se va a crear y guardar en nuestra carpeta.

FOTO 3:
Para obtener la tercera foto, que corresponde a la dilatación la cual los círculos recuperan su tamaño original tras la limpieza morfológica, usamos el siguiente comando:
( python3 Visualizer.py preprocesada.bin 3_dilatacion.png )
preprocesada.bin: Es el archivo binario original que queremos convertir a imagen visual.  
3_dilatacion.png Es el nombre del archivo de imagen final (PNG) que se va a crear y guardar en nuestra carpeta.

FOTO EXTRA:
Para obtener la foto del ruido el cual corresponde a los puntos blancos es la resta de la imagen preprocesada a la imagen original(entrada), usamos el siguiente comando:
( python3 Visualizer.py ruido.bin ruido_eliminado.png )
ruido.bin: Es el archivo binario original que queremos convertir a imagen visual.  
ruido_eliminado.png: Es el nombre del archivo de imagen final (PNG) que se va a crear y guardar en nuestra carpeta.


Paso 7: Detección visual y cruce de datos (Resultado final)
Para finalizar, en esta etapa utilizamos el visualizador avanzado. Este script genera la imagen resultante final cruzando la imagen original con los datos matemáticos obtenidos en nuestro archivo CSV. Al hacerlo, dibuja automáticamente cruces rojas que representan los centros exactos de los círculos detectados por nuestro programa en C, ejecutamos el siguiente comando:
( python3 VerificacionVisual.py -i entrada.bin -c reporte.csv -r 50 -o 4_deteccion.png )
-i entrada.bin: Es el archivo binario original que queremos convertir a imagen visual.  
-c reporte.csv: Es el archivo con la lista de coordenadas (X, Y) descubiertas por nuestro programa en C.  
-r 50: Le indica al visualizador el radio de los círculos para mantener la proporción matemática.  
-o 4_deteccion.png: Es el nombre del archivo de imagen final (PNG) que se va a crear y guardar en nuestra carpeta, junto con mostrar el resultado en una ventana emergente.

///Con esto completamos la ejecución del programa paso a paso, en caso de querer hacer mas pruebas con diferentes radios y umbrales es recomendable la ejecución del paso 8///

Paso 8: Limpieza del entorno para nuevas pruebas (Opcional)
En caso de querer ejecutar nuevamente el programa con parámetros distintos (para cambiar el tamaño de los círculos o la cantidad de ruido), debemos limpiar los archivos generados en la prueba anterior. Para esto, utilizamos el siguiente comando en la terminal:
( make clean)
Este comando ejecutará la regla de limpieza de nuestro Makefile, la cual borrará los archivos intermedios (.o), el ejecutable (lab1) y las imágenes binarias temporales (preprocesada.bin y ruido.bin).

----------------------ejemplos con distintos radios y umbrales.----------------------


